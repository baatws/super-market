import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  username: string;
  email?: string;
}

interface Product {
  id: string;
  name: string;
  image_url?: string;
  production_date: string;
  expiry_date: string;
  quantity: number;
  storage_location: string;
  status: 'active' | 'expiring_soon' | 'expired';
  created_at: string;
  updated_at: string;
}

interface Notification {
  id: string;
  product_id: string;
  product_name: string;
  message: string;
  type: 'warning' | 'danger' | 'info';
  is_read: boolean;
  created_at: string;
}

interface AppContextType {
  user: User | null;
  products: Product[];
  notifications: Notification[];
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  addProduct: (product: Omit<Product, 'id' | 'created_at' | 'updated_at' | 'status'>) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  markNotificationAsRead: (id: string) => Promise<void>;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider = ({ children }: AppProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // تحديد حالة المنتج بناءً على تاريخ الانتهاء
  const getProductStatus = (expiryDate: string): Product['status'] => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) return 'expired';
    if (daysUntilExpiry <= 7) return 'expiring_soon';
    return 'active';
  };

  // تسجيل الدخول
  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      // التحقق من بيانات الدخول الافتراضية
      if (username === 'admin' && password === 'admin') {
        const userData = {
          id: 'admin-user',
          username: 'admin',
          email: 'admin@example.com'
        };
        
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        await refreshData();
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // تسجيل الخروج
  const logout = () => {
    setUser(null);
    setProducts([]);
    setNotifications([]);
    localStorage.removeItem('user');
  };

  // إضافة منتج جديد
  const addProduct = async (productData: Omit<Product, 'id' | 'created_at' | 'updated_at' | 'status'>) => {
    try {
      const newProduct: Product = {
        ...productData,
        id: Date.now().toString(),
        status: getProductStatus(productData.expiry_date),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // إضافة إلى Supabase إذا كان متاحاً
      const { error } = await supabase
        .from('products')
        .insert([newProduct]);

      if (error && error.code !== 'PGRST116') { // تجاهل خطأ عدم وجود الجدول
        console.error('Supabase error:', error);
      }

      setProducts(prev => [...prev, newProduct]);
      
      // إنشاء تنبيه إذا كان المنتج قارب على الانتهاء
      if (newProduct.status === 'expiring_soon' || newProduct.status === 'expired') {
        const notification: Notification = {
          id: Date.now().toString() + '-notif',
          product_id: newProduct.id,
          product_name: newProduct.name,
          message: newProduct.status === 'expired' 
            ? `المنتج ${newProduct.name} منتهي الصلاحية`
            : `المنتج ${newProduct.name} قارب على انتهاء الصلاحية`,
          type: newProduct.status === 'expired' ? 'danger' : 'warning',
          is_read: false,
          created_at: new Date().toISOString(),
        };
        
        setNotifications(prev => [notification, ...prev]);
      }
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  // تحديث منتج
  const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
      const updatedProduct = {
        ...updates,
        updated_at: new Date().toISOString(),
      };

      if (updates.expiry_date) {
        updatedProduct.status = getProductStatus(updates.expiry_date);
      }

      // تحديث في Supabase
      const { error } = await supabase
        .from('products')
        .update(updatedProduct)
        .eq('id', id);

      if (error && error.code !== 'PGRST116') {
        console.error('Supabase error:', error);
      }

      setProducts(prev => prev.map(product => 
        product.id === id ? { ...product, ...updatedProduct } : product
      ));
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  // حذف منتج
  const deleteProduct = async (id: string) => {
    try {
      // حذف من Supabase
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error && error.code !== 'PGRST116') {
        console.error('Supabase error:', error);
      }

      setProducts(prev => prev.filter(product => product.id !== id));
      setNotifications(prev => prev.filter(notif => notif.product_id !== id));
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  // تحديد التنبيه كمقروء
  const markNotificationAsRead = async (id: string) => {
    try {
      setNotifications(prev => prev.map(notif => 
        notif.id === id ? { ...notif, is_read: true } : notif
      ));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  // تحديث البيانات
  const refreshData = async () => {
    try {
      setIsLoading(true);
      
      // جلب المنتجات من Supabase
      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (productsError && productsError.code !== 'PGRST116') {
        console.error('Error fetching products:', productsError);
      } else if (productsData) {
        // تحديث حالة المنتجات
        const updatedProducts = productsData.map(product => ({
          ...product,
          status: getProductStatus(product.expiry_date)
        }));
        setProducts(updatedProducts);

        // إنشاء التنبيهات للمنتجات المنتهية أو القاربة على الانتهاء
        const newNotifications: Notification[] = [];
        updatedProducts.forEach(product => {
          if (product.status === 'expiring_soon' || product.status === 'expired') {
            newNotifications.push({
              id: `${product.id}-${Date.now()}`,
              product_id: product.id,
              product_name: product.name,
              message: product.status === 'expired' 
                ? `المنتج ${product.name} منتهي الصلاحية`
                : `المنتج ${product.name} قارب على انتهاء الصلاحية`,
              type: product.status === 'expired' ? 'danger' : 'warning',
              is_read: false,
              created_at: new Date().toISOString(),
            });
          }
        });
        setNotifications(newNotifications);
      }
    } catch (error) {
      console.error('Error refreshing data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // التحقق من المصادقة عند تحميل التطبيق
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        refreshData();
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('user');
        setIsLoading(false);
      }
    } else {
      setIsLoading(false);
    }
  }, []);

  // تحديث التنبيهات كل دقيقة
  useEffect(() => {
    if (user) {
      const interval = setInterval(() => {
        refreshData();
      }, 60000); // كل دقيقة

      return () => clearInterval(interval);
    }
  }, [user]);

  const value: AppContextType = {
    user,
    products,
    notifications,
    isLoading,
    login,
    logout,
    addProduct,
    updateProduct,
    deleteProduct,
    markNotificationAsRead,
    refreshData,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};