import { createClient } from '@supabase/supabase-js';

// إعدادات Supabase - يمكن تخصيصها من متغيرات البيئة
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// دالة لإنشاء الجداول المطلوبة
export const initializeDatabase = async () => {
  try {
    // إنشاء جدول المنتجات
    const { error: productsError } = await supabase.rpc('create_products_table', {});
    if (productsError && !productsError.message.includes('already exists')) {
      console.error('Error creating products table:', productsError);
    }

    // إنشاء جدول التنبيهات
    const { error: notificationsError } = await supabase.rpc('create_notifications_table', {});
    if (notificationsError && !notificationsError.message.includes('already exists')) {
      console.error('Error creating notifications table:', notificationsError);
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
};

// دالة لطلب إذن الإشعارات
export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!('Notification' in window)) {
    console.log('This browser does not support notifications');
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  return false;
};

// دالة لإرسال إشعار محلي
export const sendLocalNotification = (title: string, body: string, icon?: string) => {
  if (Notification.permission === 'granted') {
    new Notification(title, {
      body,
      icon: icon || '/vite.svg',
      badge: '/vite.svg',
      tag: 'product-expiry',
      requireInteraction: true,
    });
  }
};

// دالة لإرسال إشعار عبر البريد الإلكتروني (يتطلب إعداد خدمة البريد)
export const sendEmailNotification = async (email: string, subject: string, message: string) => {
  try {
    // يمكن استخدام خدمة مثل EmailJS أو إرسال طلب إلى API خاص
    console.log('Sending email notification:', { email, subject, message });
    
    // مثال على استخدام fetch لإرسال البريد الإلكتروني
    // const response = await fetch('/api/send-email', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ email, subject, message }),
    // });
    
    return true;
  } catch (error) {
    console.error('Error sending email notification:', error);
    return false;
  }
};