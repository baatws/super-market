import Login from "@/components/Login";

export default function LoginStoryboard() {
  const handleLogin = (username: string, password: string) => {
    console.log("Login attempt:", { username, password });
  };

  return (
    <div className="bg-white min-h-screen">
      <Login onLogin={handleLogin} error="" loading={false} />
    </div>
  );
}
